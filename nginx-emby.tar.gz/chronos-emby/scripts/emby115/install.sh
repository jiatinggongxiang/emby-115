#!/bin/bash
source "/chronos/scripts/emby115/.venv/bin/activate"
pip install -r "/chronos/scripts/emby115/requirements.txt"